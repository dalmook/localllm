# -*- coding: utf-8 -*-
import json
import sqlite3
import uuid
from datetime import datetime


class JobStore:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()

    def _conn(self):
        return sqlite3.connect(self.db_path)

    def _init_db(self):
        with self._conn() as con:
            con.execute(
                """
                CREATE TABLE IF NOT EXISTS jobs (
                    job_id TEXT PRIMARY KEY,
                    run_at TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    executed_at TEXT,
                    error_text TEXT
                )
                """
            )
            con.commit()

    def add_job(self, payload: dict, run_at: datetime) -> str:
        job_id = str(uuid.uuid4())
        with self._conn() as con:
            con.execute(
                "INSERT INTO jobs(job_id, run_at, payload_json, status, created_at) VALUES(?,?,?,?,?)",
                (
                    job_id,
                    run_at.strftime("%Y-%m-%d %H:%M:%S"),
                    json.dumps(payload, ensure_ascii=False),
                    "PENDING",
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                ),
            )
            con.commit()
        return job_id

    def due_jobs(self) -> list[dict]:
        now_s = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._conn() as con:
            rows = con.execute(
                "SELECT job_id, run_at, payload_json FROM jobs WHERE status='PENDING' AND run_at<=? ORDER BY run_at ASC",
                (now_s,),
            ).fetchall()
        return [{"job_id": r[0], "run_at": r[1], "payload": json.loads(r[2])} for r in rows]

    def mark_done(self, job_id: str):
        with self._conn() as con:
            con.execute(
                "UPDATE jobs SET status='DONE', executed_at=? WHERE job_id=?",
                (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), job_id),
            )
            con.commit()

    def mark_error(self, job_id: str, err: str):
        with self._conn() as con:
            con.execute(
                "UPDATE jobs SET status='ERROR', executed_at=?, error_text=? WHERE job_id=?",
                (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), err[:4000], job_id),
            )
            con.commit()

    def list_recent(self, limit: int = 30) -> list[dict]:
        with self._conn() as con:
            rows = con.execute(
                "SELECT job_id, run_at, status, payload_json, error_text FROM jobs ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [
            {"job_id": r[0], "run_at": r[1], "status": r[2], "payload": json.loads(r[3]), "error_text": r[4]}
            for r in rows
        ]
