# -*- coding: utf-8 -*-
from __future__ import annotations

import queue
import threading
import tkinter as tk

from config import APP_GEOMETRY, APP_TITLE, POLL_MS
from chat_controller import ChatController


class ChatApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry(APP_GEOMETRY)
        self.root.configure(bg="#f5f7fb")

        self.ui_queue: queue.Queue[tuple[str, str]] = queue.Queue()
        self.controller = ChatController(self._post_ui)
        self._copy_menu: tk.Menu | None = None

        self._build_ui()
        self._append_system(
            "안녕하세요. 자연어로 Knox 발송/예약/Oracle 조회를 도와드릴게요.\n"
            "예: sungmook.cho에게 지금 테스트 메시지 보내줘\n"
            "예: 연홍석에게 2시간 뒤에 회의 시작이라고 보내줘\n"
            "예: K9YHGB8J1M 조회해줘"
        )
        self._append_system("앱 시작 중... Knox 엔진 초기화와 사람 캐시 점검을 진행합니다.")

        threading.Thread(target=self._bootstrap_engine, daemon=True).start()
        self.root.after(250, self._drain_ui_queue)
        self.root.after(POLL_MS, self._poll_jobs)
        self.root.bind_all("<Control-c>", self._on_global_copy, add="+")
        self.root.bind_all("<Control-C>", self._on_global_copy, add="+")

    def _build_ui(self):
        header = tk.Frame(self.root, bg="#ffffff", height=54)
        header.pack(fill="x")
        tk.Label(
            header,
            text=APP_TITLE,
            font=("Malgun Gothic", 15, "bold"),
            bg="#ffffff",
            fg="#1f2937",
        ).pack(side="left", padx=16, pady=12)
        self.status_var = tk.StringVar(value="시작 중")
        tk.Label(
            header,
            textvariable=self.status_var,
            font=("Malgun Gothic", 10),
            bg="#ffffff",
            fg="#6b7280",
        ).pack(side="right", padx=16)

        body = tk.Frame(self.root, bg="#f5f7fb")
        body.pack(fill="both", expand=True)

        self.canvas = tk.Canvas(body, bg="#f5f7fb", highlightthickness=0)
        self.scrollbar = tk.Scrollbar(body, orient="vertical", command=self.canvas.yview)
        self.msg_frame = tk.Frame(self.canvas, bg="#f5f7fb")
        self.msg_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.create_window((0, 0), window=self.msg_frame, anchor="nw", width=920)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True, padx=(14, 0), pady=(12, 8))
        self.scrollbar.pack(side="right", fill="y", pady=(12, 8), padx=(0, 14))

        bottom = tk.Frame(self.root, bg="#ffffff", height=100)
        bottom.pack(fill="x")

        tk.Label(
            bottom,
            text=(
                "예: 연홍석에게 지금 테스트 메시지 보내줘 / 조성묵에게 2시간 뒤에 회의 시작이라고 보내줘 / "
                "K9YHGB8J1M 조회해줘 / 최근 예약 보여줘 / 표로 보내줘 / 사람 캐시 새로고침"
            ),
            font=("Malgun Gothic", 9),
            bg="#ffffff",
            fg="#6b7280",
            anchor="w",
            justify="left",
        ).pack(fill="x", padx=16, pady=(10, 4))

        input_wrap = tk.Frame(bottom, bg="#ffffff")
        input_wrap.pack(fill="x", padx=14, pady=(0, 14))

        self.entry = tk.Text(input_wrap, height=3, font=("Malgun Gothic", 11), wrap="word", relief="solid", bd=1)
        self.entry.pack(side="left", fill="both", expand=True, padx=(2, 8))
        self.entry.bind("<Return>", self._on_enter)
        self.entry.bind("<Shift-Return>", lambda e: None)

        tk.Button(
            input_wrap,
            text="보내기",
            command=self._send_current_text,
            font=("Malgun Gothic", 11, "bold"),
            bg="#2563eb",
            fg="white",
            activebackground="#1d4ed8",
            activeforeground="white",
            relief="flat",
            padx=20,
            pady=12,
        ).pack(side="right")

    def _estimate_bubble_height(self, text: str, wrap_chars: int = 58) -> int:
        lines = text.splitlines() or [""]
        total = 0
        for line in lines:
            total += max(1, (len(line) // wrap_chars) + 1)
        return max(1, min(total, 18))

    def _copy_selected_from_widget(self, widget: tk.Text):
        try:
            selected = widget.get("sel.first", "sel.last")
        except Exception:
            selected = ""
        if selected:
            self.root.clipboard_clear()
            self.root.clipboard_append(selected)

    def _copy_all_from_widget(self, widget: tk.Text):
        text = widget.get("1.0", "end-1c")
        self.root.clipboard_clear()
        self.root.clipboard_append(text)

    def _show_copy_menu(self, event, widget: tk.Text):
        if self._copy_menu is None:
            self._copy_menu = tk.Menu(self.root, tearoff=0)
        else:
            self._copy_menu.delete(0, "end")

        try:
            selected = widget.get("sel.first", "sel.last")
        except Exception:
            selected = ""

        if selected:
            self._copy_menu.add_command(label="선택 복사", command=lambda w=widget: self._copy_selected_from_widget(w))
        self._copy_menu.add_command(label="전체 복사", command=lambda w=widget: self._copy_all_from_widget(w))

        try:
            self._copy_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self._copy_menu.grab_release()

    def _on_global_copy(self, event=None):
        widget = self.root.focus_get()
        if not isinstance(widget, tk.Text):
            return None
        try:
            selected = widget.get("sel.first", "sel.last")
        except Exception:
            selected = ""
        if selected:
            self.root.clipboard_clear()
            self.root.clipboard_append(selected)
            return "break"
        return None

    def _bubble(self, side: str, text: str, tone: str = "normal"):
        outer = tk.Frame(self.msg_frame, bg="#f5f7fb")
        outer.pack(fill="x", pady=5, padx=6)
        row = tk.Frame(outer, bg="#f5f7fb")
        row.pack(fill="x")

        if side == "right":
            bg, fg = "#2563eb", "white"
        else:
            bg, fg = ("#ffffff", "#111827") if tone == "normal" else ("#eef6ff", "#111827")

        bubble = tk.Text(
            row,
            font=("Malgun Gothic", 10),
            bg=bg,
            fg=fg,
            relief="solid",
            bd=1,
            wrap="word",
            width=58,
            height=self._estimate_bubble_height(text),
            padx=14,
            pady=10,
            cursor="xterm",
            highlightthickness=0,
            insertwidth=0,
            undo=False,
        )
        bubble.insert("1.0", text)
        bubble.tag_add("all", "1.0", "end-1c")
        bubble.tag_configure("all", justify="left")
        bubble.bind("<Key>", lambda e: "break")
        bubble.bind("<Button-1>", lambda e, w=bubble: w.focus_set())
        bubble.bind("<Control-a>", lambda e, w=bubble: (w.tag_add("sel", "1.0", "end-1c"), "break"))
        bubble.bind("<Control-A>", lambda e, w=bubble: (w.tag_add("sel", "1.0", "end-1c"), "break"))
        bubble.bind("<Control-c>", lambda e, w=bubble: (self._copy_selected_from_widget(w), "break"))
        bubble.bind("<Control-C>", lambda e, w=bubble: (self._copy_selected_from_widget(w), "break"))
        bubble.bind("<Button-3>", lambda e, w=bubble: self._show_copy_menu(e, w))

        if side == "right":
            bubble.pack(side="right")
        else:
            bubble.pack(side="left")

        self.root.update_idletasks()
        self.canvas.yview_moveto(1.0)

    def _append_user(self, text: str):
        self._bubble("right", text)

    def _append_assistant(self, text: str):
        self._bubble("left", text)

    def _append_system(self, text: str):
        self._bubble("left", text, tone="system")

    def _set_status(self, text: str):
        self.status_var.set(text)

    def _post_ui(self, kind: str, text: str):
        self.ui_queue.put((kind, text))

    def _bootstrap_engine(self):
        try:
            result = self.controller.bootstrap_engine()
            self._post_ui("status", "Knox 연결 완료")
            cache_msg = result.get("people_cache") or {}
            extra = ""
            if cache_msg:
                extra = f"\n- 사람캐시: {cache_msg.get('count', 0)}건 / {cache_msg.get('updated_at', '')}"
            self._post_ui(
                "assistant",
                f"Knox 초기화 완료\n- device: {result['device']['deviceServerID']}\n- userID: {result['device']['userID']}" + extra,
            )
        except Exception as exc:
            self._post_ui("status", "Knox 초기화 실패")
            self._post_ui("assistant", f"Knox 초기화 실패: {exc}")

    def _on_enter(self, event):
        if event.state & 0x0001:
            return None
        self._send_current_text()
        return "break"

    def _send_current_text(self):
        text = self.entry.get("1.0", "end").strip()
        if not text:
            return
        self.entry.delete("1.0", "end")
        self._append_user(text)
        self._set_status("생각 중...")
        threading.Thread(target=self._handle_user_message, args=(text,), daemon=True).start()

    def _handle_user_message(self, text: str):
        try:
            msg = self.controller.handle_text(text)
            if msg:
                self._post_ui("assistant", msg)
            self._post_ui("status", "대기 중")
        except Exception as exc:
            self._post_ui("assistant", f"처리 중 오류가 발생했어요.\n{exc}")
            self._post_ui("status", "오류")

    def _poll_jobs(self):
        try:
            msgs = self.controller.poll_jobs()
            for msg in msgs:
                self._append_system(msg)
        except Exception as exc:
            self._append_system(f"예약 작업 점검 오류: {exc}")
        finally:
            self.root.after(POLL_MS, self._poll_jobs)

    def _drain_ui_queue(self):
        while True:
            try:
                kind, text = self.ui_queue.get_nowait()
            except queue.Empty:
                break
            if kind == "assistant":
                self._append_assistant(text)
            elif kind == "status":
                self._set_status(text)
        self.root.after(250, self._drain_ui_queue)


def main():
    root = tk.Tk()
    ChatApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
