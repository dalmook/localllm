# -*- coding: utf-8 -*-
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
CACHE_DIR = BASE_DIR / "cache"
CACHE_DIR.mkdir(exist_ok=True)

# =========================
# GPT-OSS 설정 (사용자 제공 예제 기준)
# =========================
GPT_API_BASE_URL = "http://apigw.samsungds.net:8000/gpt-oss/1/gpt-oss-120b/v1/chat/completions"
GPT_CREDENTIAL_KEY = "credential:TICKET-96f7bce0-efab-4516-8e62-5501b07ab43c:ST0000107488-PROD:CTXLCkSDRGWtI5HdVHkPAQgol2o-RyQiq2I1vCHHOgGw:-1:Q1RYTENrU0RSR1d0STVIZFZIa1BBUWdvbDJvLVJ5UWlxMkkxdkNISE9nR3c=:signature=eRa1UcfmWGfKTDBt-Xnz2wFhW0OvMX0WESZUpoNVgCA5uNVgpgax59LZ3osPOp8whnZwQay8s5TUvxJGtmsCD9iK-HpcsyUOcE5P58W0Weyg-YQ3KRTWFiA=="
GPT_USER_ID = "sungmook.cho"
GPT_USER_TYPE = "AD_ID"
GPT_SEND_SYSTEM_NAME = "GOC_MAIL_RAG_PIPELINE"
GPT_MODEL = "openai/gpt-oss-120b"

# =========================
# Knox 설정
# =========================
KNOX_HOST = "https://openapi.samsung.net"
KNOX_SYSTEM_ID = "PUT_REAL_KNOX_SYSTEM_ID_HERE"
KNOX_TOKEN = "PUT_REAL_KNOX_TOKEN_HERE"
KNOX_DEVICE_TYPE = "relation"
KNOX_VERIFY_SSL = False

# =========================
# Oracle 설정 (사용자 제공값)
# =========================
ORACLE_HOST = "gmgsdd09-vip.sec.samsung.net"
ORACLE_PORT = 2541
ORACLE_SERVICE = "MEMSCM"
ORACLE_USER = "memscm"
ORACLE_PW = "mem01scm"
ORACLE_LIB_DIR = None  # 예: r"C:\instantclient"

# =========================
# 앱 설정
# =========================
APP_TITLE = "Knox + Oracle Chat"
APP_GEOMETRY = "980x820"
DB_PATH = str(BASE_DIR / "chat_jobs.db")
POLL_MS = 4000
MAX_RESULT_ROWS = 100
PEOPLE_CACHE_PATH = str(CACHE_DIR / "people_directory_cache.json")
PEOPLE_CACHE_MAX_AGE_HOURS = 12

NAME_ALIAS = {
    "조성묵": "sungmook.cho",
    "성묵님": "sungmook.cho",
    "성묵": "sungmook.cho",
    "나": "sungmook.cho",
    "저": "sungmook.cho",
}
