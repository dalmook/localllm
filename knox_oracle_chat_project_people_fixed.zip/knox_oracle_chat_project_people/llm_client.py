# -*- coding: utf-8 -*-
import json
import uuid
import requests

from config import (
    GPT_API_BASE_URL,
    GPT_CREDENTIAL_KEY,
    GPT_MODEL,
    GPT_SEND_SYSTEM_NAME,
    GPT_USER_ID,
    GPT_USER_TYPE,
)


class GptOssClient:
    def __init__(self):
        self.api_base_url = GPT_API_BASE_URL
        self.credential_key = GPT_CREDENTIAL_KEY
        self.user_id = GPT_USER_ID
        self.user_type = GPT_USER_TYPE
        self.send_system_name = GPT_SEND_SYSTEM_NAME
        self.model = GPT_MODEL

    def chat(self, prompt: str, system_prompt: str | None = None, temperature: float = 0.1, max_tokens: int = 700) -> dict:
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        payload = json.dumps({
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False,
        })

        headers = {
            "x-dep-ticket": self.credential_key,
            "Send-System-Name": self.send_system_name,
            "User-Id": self.user_id,
            "User-Type": self.user_type,
            "Prompt-Msg-Id": str(uuid.uuid4()),
            "Completion-Msg-Id": str(uuid.uuid4()),
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

        resp = requests.post(self.api_base_url, headers=headers, data=payload, timeout=90)
        resp.raise_for_status()
        return resp.json()

    def chat_text(self, prompt: str, system_prompt: str | None = None, temperature: float = 0.1, max_tokens: int = 700) -> str:
        data = self.chat(prompt, system_prompt=system_prompt, temperature=temperature, max_tokens=max_tokens)
        return data["choices"][0]["message"]["content"]
