# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path

from config import NAME_ALIAS, PEOPLE_CACHE_MAX_AGE_HOURS, PEOPLE_CACHE_PATH
from .db import OracleClient
from .queries.people_directory import SQL_PEOPLE_DIRECTORY

LOGINID_RE = re.compile(r"^[A-Za-z0-9_.-]{3,}$")

@dataclass
class PeopleResolveResult:
    resolved_loginids: list[str]
    missing_inputs: list[str]
    ambiguous: dict[str, list[dict]]


class PeopleDirectoryService:
    def __init__(self, oracle_client: OracleClient):
        self.oracle = oracle_client
        self.cache_path = Path(PEOPLE_CACHE_PATH)
        self.rows: list[dict] = []
        self._load_cache()

    def _load_cache(self):
        if not self.cache_path.exists():
            self.rows = []
            return
        try:
            data = json.loads(self.cache_path.read_text(encoding='utf-8'))
            self.rows = data.get('rows', []) or []
        except Exception:
            self.rows = []

    def _save_cache(self, rows: list[dict]):
        payload = {
            'updated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'count': len(rows),
            'rows': rows,
        }
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        self.cache_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
        self.rows = rows

    def cache_info(self) -> dict:
        if not self.cache_path.exists():
            return {'exists': False, 'count': 0, 'updated_at': ''}
        try:
            data = json.loads(self.cache_path.read_text(encoding='utf-8'))
            return {
                'exists': True,
                'count': int(data.get('count', 0) or 0),
                'updated_at': data.get('updated_at', ''),
            }
        except Exception:
            return {'exists': False, 'count': 0, 'updated_at': ''}

    def cache_is_stale(self) -> bool:
        info = self.cache_info()
        if not info['exists']:
            return True
        try:
            updated = datetime.strptime(info['updated_at'], '%Y-%m-%d %H:%M:%S')
        except Exception:
            return True
        return updated < datetime.now() - timedelta(hours=PEOPLE_CACHE_MAX_AGE_HOURS)

    def refresh_cache(self) -> dict:
        df = self.oracle.query_df(SQL_PEOPLE_DIRECTORY)
        rows = []
        for _, row in df.fillna('').iterrows():
            rows.append({
                'dept_name': str(row.get('DEPT_NAME', '')).strip(),
                'sso_id': str(row.get('SSO_ID', '')).strip(),
                'kor_name': str(row.get('KOR_NAME', '')).strip(),
            })
        self._save_cache(rows)
        return self.cache_info()

    def refresh_cache_if_needed(self) -> dict:
        if self.cache_is_stale() or not self.rows:
            return self.refresh_cache()
        return self.cache_info()

    def _norm(self, value: str) -> str:
        return re.sub(r'\s+', '', (value or '').strip()).lower()

    def search_by_name(self, name: str) -> list[dict]:
        target = self._norm(name)
        if not target:
            return []
        exact = [r for r in self.rows if self._norm(r.get('kor_name', '')) == target]
        if exact:
            return exact
        partial = [r for r in self.rows if target in self._norm(r.get('kor_name', ''))]
        return partial

    def resolve_targets(self, targets: list[str]) -> PeopleResolveResult:
        resolved_loginids: list[str] = []
        missing_inputs: list[str] = []
        ambiguous: dict[str, list[dict]] = {}

        for raw in targets:
            key = (raw or '').strip()
            if not key:
                continue
            if key in NAME_ALIAS:
                resolved_loginids.append(NAME_ALIAS[key])
                continue
            if LOGINID_RE.match(key) and '.' in key or '_' in key:
                resolved_loginids.append(key)
                continue
            candidates = self.search_by_name(key)
            uniq = []
            seen = set()
            for c in candidates:
                sso = c.get('sso_id', '')
                if sso and sso not in seen:
                    seen.add(sso)
                    uniq.append(c)
            if len(uniq) == 1:
                resolved_loginids.append(uniq[0]['sso_id'])
            elif len(uniq) > 1:
                ambiguous[key] = uniq[:10]
            else:
                missing_inputs.append(key)

        # dedupe preserve order
        out = []
        seen = set()
        for x in resolved_loginids:
            if x not in seen:
                seen.add(x)
                out.append(x)
        return PeopleResolveResult(out, missing_inputs, ambiguous)
