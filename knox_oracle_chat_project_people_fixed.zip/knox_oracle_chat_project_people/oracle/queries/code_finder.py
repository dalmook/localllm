# -*- coding: utf-8 -*-
SQL_CODE_FINDER = r"""
WITH version as (
SELECT
AA.ITEM,
AA.fam6_code,
DECODE(NVL(BB.VER,DD.DRAM_VER),'-',SUBSTR(AA.FAM6_CODE,-3,2),NVL(BB.VER,DD.DRAM_VER)) DRAMVER,
NVL(CC.VER,DD.NAND_VER) NANDVER
FROM 
(select
    a.SALES_CODE ITEM,
    a.fam6_code
from V_IF_MDM_C_BS_CM_SALES_FAMILY a
) AA, (select A.item, max(version) ver from MST_PAX_ITEM a where 1=1 group by A.item) BB, (SELECT PARTNO ITEM, MAX(VERSION) VER  FROM MST_PKGMASTERFLASH A  WHERE 1=1  AND A.ISVALID = 'Y'  GROUP BY PARTNO) CC
,(SELECT DISTINCT ITEM,DRAM_VER, NAND_VER FROM MEMPM_SDB.EXP_ITEM A WHERE 1=1 AND a.plan_version  = (select max(plan_version) from  MEMPM_SDB.EXP_ITEM )) DD
WHERE AA.item = BB.ITEM (+)
AND AA.item = CC.ITEM (+)
AND AA.item = DD.ITEM (+)
),
MOQ AS 
(select
a.item,
a.lboxqty,
a.sboxqty,
a.lboxqty * a.sboxqty moq
from tar_moq a
where 1=1
and a.gbm = 'MEM'
GROUP BY
a.item,
a.lboxqty,
a.sboxqty,
a.lboxqty * a.sboxqty)
       SELECT
           AA.ITEM,
           AA.DENSITY,
           AA.APPLICATION,
           AA.PRODUCT,
           AA.MODEL,
           MAX(AA.DRAMVER) DRAMVER,
           MAX(NVL(AA.NANDVER,BB.NANDVER)) NANDVER,
           AA.MULTIGUBUN,
           AA.FF,
           AA.IF, 
           AA.CATEGORY1,
           AA.CATEGORY2,
           AA.CONTROLLER,
           AA.NANDDR, 
           AA.BIT,
           AA.NANDDEN,
           AA.NANDCOMPEQ,
           AA.NANDCOMP,
           AA.NANDEQ,
           AA.DRAMDR,
           AA.DRAMSUB, 
           AA.DRAMDEN,
           AA.DRAMCOMPEQ,
           AA.DRAMCOMP,
           AA.DRAMEQ,
           CC.LBOXQTY,
           CC.SBOXQTY,
           CC.MOQ
       FROM
           (SELECT
               A.ITEM,
               A.DENSITY,
               A.APPLICATION,
               A.PRODUCT,
               A.MODEL,
               B.DRAMVER,
               '' NANDVER,
               A.MULTIGUBUN,
               A.FF,
               A.IF, 
               A.CATEGORY1,
               A.CATEGORY2,
               A.CONTROLLER,
               A.NANDDR, 
               A.BIT,
               A.NANDDENSITY NANDDEN,
               A.NANDCOMPEQQTY NANDCOMPEQ,
               A.NANDCOMPQTY NANDCOMP,
               A.NANDEQQTY NANDEQ,
               A.DRAMDR,
               A.DRAMSUBPRODUCT DRAMSUB, 
               A.DRAMDENSITY DRAMDEN,
               A.DRAMCOMPEQQTY DRAMCOMPEQ,
               A.DRAMCOMPQTY DRAMCOMP,
               A.DRAMEQQTY DRAMEQ
           FROM
               MST_PAX_ITEM A
               LEFT JOIN VERSION B ON A.ITEM = B.ITEM
           UNION ALL
           SELECT
               A.ITEM,
               A.DENSITY,
               A.APPLICATION,
               A.PRODUCT,
               A.MODEL,
               '' DRAMVER,
               C.VERSION,
               A.MULTIGUBUN,
               A.FF,
               A.IF, 
               A.CATEGORY1,
               A.CATEGORY2,
               A.CONTROLLER,
               A.NANDDR, 
               A.BIT,
               A.NANDDENSITY NANDDEN,
               A.NANDCOMPEQQTY NANDCOMPEQ,
               A.NANDCOMPQTY NANDCOMP,
               A.NANDEQQTY NANDEQ,
               A.DRAMDR,
               A.DRAMSUBPRODUCT DRAMSUB, 
               A.DRAMDENSITY DRAMDEN,
               A.DRAMCOMPEQQTY DRAMCOMPEQ,
               A.DRAMCOMPQTY DRAMCOMP,
               A.DRAMEQQTY DRAMEQ
           FROM
               MST_PAX_ITEM A
               LEFT JOIN MST_WHINMASTERFLASH C ON A.ITEM = C.SALESCODE
           ) AA LEFT JOIN VERSION BB ON AA.ITEM = BB.ITEM
           LEFT OUTER JOIN MOQ CC ON AA.ITEM = CC.ITEM
       WHERE
           AA.ITEM LIKE :item
           AND ROWNUM <= 100
       GROUP BY
           AA.ITEM,
           AA.DENSITY,
           AA.APPLICATION,
           AA.PRODUCT,
           AA.MODEL,
           AA.MULTIGUBUN,
           AA.FF,
           AA.IF, 
           AA.CATEGORY1,
           AA.CATEGORY2,
           AA.CONTROLLER,
           AA.NANDDR, 
           AA.BIT,
           AA.NANDDEN,
           AA.NANDCOMPEQ,
           AA.NANDCOMP,
           AA.NANDEQ,
           AA.DRAMDR,
           AA.DRAMSUB, 
           AA.DRAMDEN,
           AA.DRAMCOMPEQ,
           AA.DRAMCOMP,
           AA.DRAMEQ,
           CC.LBOXQTY,
           CC.SBOXQTY,
           CC.MOQ
"""
