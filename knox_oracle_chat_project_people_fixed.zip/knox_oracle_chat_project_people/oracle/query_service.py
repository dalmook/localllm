# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

import pandas as pd

from config import MAX_RESULT_ROWS
from .db import OracleClient
from .query_registry import QUERY_REGISTRY, QueryDef

SUMMARY_SYSTEM_PROMPT = """
너는 Oracle 조회 결과를 사내 사용자에게 이해하기 쉽게 설명하는 요약 비서다.
반드시 한국어로 답한다.
다음 규칙을 지켜라:
1) 가장 중요한 값부터 짧게 요약
2) ITEM, PRODUCT, MODEL, DRAMVER, NANDVER, CONTROLLER, MOQ가 있으면 우선 언급
3) 행이 여러 개인 경우 중복을 줄여 요약
4) 마지막에 '원하면 표로 Knox 전송도 가능' 한 줄 추가
"""


@dataclass
class QueryResult:
    query_name: str
    title: str
    params: dict[str, Any]
    df: pd.DataFrame
    summary: str


class QueryService:
    def __init__(self, oracle_client: OracleClient, llm_client):
        self.oracle = oracle_client
        self.llm = llm_client

    def available_queries(self) -> list[str]:
        return list(QUERY_REGISTRY.keys())

    def guess_query(self, user_text: str) -> tuple[str | None, dict[str, Any]]:
        text = user_text.strip()
        m = re.search(r"([A-Za-z0-9._\-/]{4,})", text)
        if m:
            token = m.group(1)
            if any(k in text for k in ["조회", "찾", "품번", "파트", "part", "code", "모델"]) or token:
                return "code_finder", {"item": token}
        return None, {}

    def execute(self, query_name: str, params: dict[str, Any]) -> QueryResult:
        if query_name not in QUERY_REGISTRY:
            raise ValueError(f"등록되지 않은 query_name 입니다: {query_name}")
        qd: QueryDef = QUERY_REGISTRY[query_name]
        binds = qd.bind_builder(params)
        df = self.oracle.query_df(qd.sql, binds=binds)
        if len(df) > MAX_RESULT_ROWS:
            df = df.head(MAX_RESULT_ROWS).copy()
        summary = self.summarize_result(qd, params, df)
        return QueryResult(query_name=qd.name, title=qd.default_title, params=params, df=df, summary=summary)

    def summarize_result(self, qd: QueryDef, params: dict[str, Any], df: pd.DataFrame) -> str:
        if df is None or df.empty:
            return "조회 결과가 없습니다. 품번 일부만 넣어서 다시 시도해보세요."

        records = df.head(10).fillna("").to_dict(orient="records")
        prompt = (
            f"query_name={qd.name}\n"
            f"description={qd.description}\n"
            f"params={json.dumps(params, ensure_ascii=False)}\n"
            f"rows={json.dumps(records, ensure_ascii=False)}"
        )
        try:
            return self.llm.chat_text(prompt, system_prompt=SUMMARY_SYSTEM_PROMPT, temperature=0.1, max_tokens=700).strip()
        except Exception:
            first = records[0]
            item = first.get("ITEM", "")
            prod = first.get("PRODUCT", "")
            model = first.get("MODEL", "")
            dram = first.get("DRAMVER", "")
            nand = first.get("NANDVER", "")
            moq = first.get("MOQ", "")
            return f"조회 결과 {len(df)}건입니다. ITEM={item}, PRODUCT={prod}, MODEL={model}, DRAMVER={dram}, NANDVER={nand}, MOQ={moq}"
