# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from .queries.code_finder import SQL_CODE_FINDER


@dataclass
class QueryDef:
    name: str
    description: str
    sql: str
    bind_builder: Callable[[dict], dict]
    default_title: str


def build_code_finder_binds(params: dict) -> dict:
    item = (params.get("item") or "").strip().upper()
    if not item:
        raise ValueError("조회할 파트넘버가 비어 있습니다.")
    if "%" not in item:
        item = f"%{item}%"
    return {"item": item}


QUERY_REGISTRY: dict[str, QueryDef] = {
    "code_finder": QueryDef(
        name="code_finder",
        description="파트넘버 기본 정보, 버전, NAND/DRAM, MOQ 조회",
        sql=SQL_CODE_FINDER,
        bind_builder=build_code_finder_binds,
        default_title="파트넘버 조회 결과",
    ),
}
