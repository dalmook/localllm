# -*- coding: utf-8 -*-
from __future__ import annotations

import oracledb
import pandas as pd

from config import ORACLE_HOST, ORACLE_LIB_DIR, ORACLE_PORT, ORACLE_PW, ORACLE_SERVICE, ORACLE_USER


class OracleClient:
    def __init__(self):
        self.user = ORACLE_USER
        self.password = ORACLE_PW
        self.host = ORACLE_HOST
        self.port = ORACLE_PORT
        self.service = ORACLE_SERVICE
        self._init_done = False
        self._maybe_init_client()

    def _maybe_init_client(self):
        if self._init_done:
            return
        if ORACLE_LIB_DIR:
            try:
                oracledb.init_oracle_client(lib_dir=ORACLE_LIB_DIR)
            except Exception:
                pass
        self._init_done = True

    def connect(self):
        dsn = f"{self.host}:{self.port}/{self.service}"
        return oracledb.connect(user=self.user, password=self.password, dsn=dsn)

    def query_df(self, sql: str, binds: dict | None = None) -> pd.DataFrame:
        with self.connect() as con:
            return pd.read_sql(sql, con=con, params=binds or {})
