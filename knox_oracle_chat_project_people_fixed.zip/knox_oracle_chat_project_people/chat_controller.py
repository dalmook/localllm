# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any

import pandas as pd

from config import (
    DB_PATH,
    KNOX_DEVICE_TYPE,
    KNOX_HOST,
    KNOX_SYSTEM_ID,
    KNOX_TOKEN,
    KNOX_VERIFY_SSL,
)
from knox_messenger_engine import KnoxConfig, KnoxMessengerEngine
from llm_client import GptOssClient
from oracle import OracleClient, PeopleDirectoryService, QueryResult, QueryService
from scheduler_store import JobStore

PLANNER_SYSTEM_PROMPT = """
너는 사내 챗앱 planner다.
반드시 JSON만 출력한다. 설명/코드블록 금지.
현재 시각(Asia/Seoul): {now_kst}

지원 intent:
- send_message_now
- schedule_message
- send_table_now
- send_card_now
- oracle_query
- list_jobs
- refresh_people_cache
- chat

JSON 스키마:
{{
  "intent": "send_message_now|schedule_message|send_table_now|send_card_now|oracle_query|list_jobs|refresh_people_cache|chat",
  "targets": ["loginid 또는 한글 이름"],
  "message": "보낼 문구 또는 요청 요약",
  "chat_type": 0,
  "delay_minutes": 0,
  "scheduled_at": "YYYY-MM-DD HH:MM",
  "table_title": "표 제목",
  "query_name": "code_finder",
  "query_params": {{"item": ""}},
  "needs_confirmation": false,
  "confidence": 0.0,
  "reason": ""
}}

규칙:
1) 최근 대화 맥락을 반드시 참고한다. 현재 입력이 짧아도 직전 질문의 빈칸을 채우는 답변일 수 있다.
2) 지금/바로/즉시는 send_message_now
3) N분 뒤 / N시간 뒤 / 내일 오전 9시 같은 예약은 schedule_message
4) 표/테이블/조회결과 보내기는 send_table_now
5) 카드/적응형 카드 보내기는 send_card_now
6) 품번/파트넘버/코드 조회는 oracle_query
7) 예약 목록/최근 예약은 list_jobs
8) 사람 캐시 새로고침은 refresh_people_cache
9) 기능과 무관한 일반 대화는 chat
10) 불명확하면 needs_confirmation=true
11) 사람 이름은 한글 그대로 targets에 넣어도 된다
12) query_name은 현재 code_finder만 사용한다
"""

CHAT_SYSTEM_PROMPT = """
너는 친절한 사내 채팅 비서다.
답변은 짧고 자연스럽게 한국어로 한다.
반드시 최근 대화 맥락을 이어서 답한다.
이전 질문의 빈칸을 사용자가 채우면 그 맥락을 이어서 답변한다.
모르는 기능은 솔직히 말하고, 가능한 예시를 한두 개 덧붙여도 된다.
"""

SLOT_FILL_SYSTEM_PROMPT = """
너는 사내 챗앱의 pending plan 보완기다.
반드시 JSON만 출력한다. 설명/코드블록 금지.
기존 plan JSON과 최근 대화, 사용자의 추가 입력을 보고 plan을 업데이트한다.
규칙:
1) 기존 값은 유지하고, 새로 알게 된 값만 채운다.
2) 사용자가 짧게만 말해도 직전 질문의 빈칸을 채우는 것으로 해석한다.
3) 결과는 최종 JSON 하나만 출력한다.
"""

CARD_TEMPLATE = {
    "type": "AdaptiveCard",
    "version": "1.4",
    "body": [
        {"type": "TextBlock", "text": "Knox 카드 테스트", "weight": "Bolder", "size": "Medium"},
        {"type": "TextBlock", "text": "이 카드는 엔진 테스트용으로 전송됩니다.", "wrap": True},
    ],
}

YES_WORDS = {"응", "네", "예", "ㅇㅇ", "맞아", "진행", "보내", "그래", "ok", "okay", "y", "yes"}
NO_WORDS = {"아니", "아니오", "취소", "그만", "안해", "n", "no"}


@dataclass
class PendingAction:
    plan: dict[str, Any]


@dataclass
class PendingFill:
    plan: dict[str, Any]
    missing_field: str
    question: str


class ChatController:
    def __init__(self, ui_callback):
        self.ui_callback = ui_callback
        self.llm = GptOssClient()
        self.job_store = JobStore(DB_PATH)
        self.oracle = OracleClient()
        self.people = PeopleDirectoryService(self.oracle)
        self.query_service = QueryService(self.oracle, self.llm)
        self.knox = KnoxMessengerEngine(
            KnoxConfig(
                host=KNOX_HOST,
                system_id=KNOX_SYSTEM_ID,
                token=KNOX_TOKEN,
                device_type=KNOX_DEVICE_TYPE,
                verify_ssl=KNOX_VERIFY_SSL,
                proxies=None,
            )
        )
        self.pending_action: PendingAction | None = None
        self.pending_fill: PendingFill | None = None
        self.last_query_result: QueryResult | None = None
        self.engine_ready = False
        self.history: list[dict[str, str]] = []

    def bootstrap_engine(self) -> dict[str, Any]:
        result = self.knox.bootstrap()
        self.engine_ready = True
        result["people_cache"] = self.people.refresh_cache_if_needed()
        return result

    def handle_text(self, text: str) -> str:
        text = text.strip()
        if not text:
            return ""
        self._add_history("user", text)
        response = self._handle_text_core(text)
        if response:
            self._add_history("assistant", response)
        return response

    def poll_jobs(self) -> list[str]:
        messages: list[str] = []
        for job in self.job_store.due_jobs():
            try:
                result = self._execute_plan(job["payload"])
                self.job_store.mark_done(job["job_id"])
                msg = f"[예약 실행 완료]\n{result}"
            except Exception as exc:
                self.job_store.mark_error(job["job_id"], str(exc))
                msg = f"[예약 실행 실패]\n{exc}"
            messages.append(msg)
            self._add_history("assistant", msg)
        return messages

    def _handle_text_core(self, text: str) -> str:
        if self.pending_action:
            return self._handle_confirmation(text)
        if self.pending_fill:
            return self._handle_pending_fill(text)
        if self._looks_like_local_command(text):
            return self._handle_local_command(text)

        query_name, params = self.query_service.guess_query(text)
        if query_name:
            result = self.query_service.execute(query_name, params)
            self.last_query_result = result
            return result.summary

        plan = self._plan(text)
        intent = plan.get("intent", "chat")

        if intent == "chat":
            return self._chat_reply(text)
        if intent == "refresh_people_cache":
            info = self.people.refresh_cache()
            return f"사람 캐시를 새로고침했어요.\n- 건수: {info.get('count', 0)}\n- 시각: {info.get('updated_at', '')}"
        if intent == "list_jobs":
            return self._format_recent_jobs()
        if intent == "oracle_query":
            if not (plan.get("query_params") or {}).get("item"):
                return self._ask_for_missing(plan, "item")
            result = self.query_service.execute(plan.get("query_name") or "code_finder", plan.get("query_params") or {})
            self.last_query_result = result
            return result.summary

        missing_field = self._find_missing_field(plan)
        if missing_field:
            return self._ask_for_missing(plan, missing_field)

        rendered = self._render_plan(plan)
        if plan.get("needs_confirmation"):
            self.pending_action = PendingAction(plan=plan)
            return rendered + "\n\n진행할까요? (응/아니오)"

        return rendered + "\n\n" + self._execute_plan(plan)

    def _plan(self, user_text: str) -> dict[str, Any]:
        now_kst = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        prompt = (
            f"최근 대화:\n{self._history_block(limit=8)}\n\n"
            f"현재 사용자 입력:\n{user_text}"
        )
        raw = self.llm.chat_text(
            prompt,
            system_prompt=PLANNER_SYSTEM_PROMPT.format(now_kst=now_kst),
            temperature=0.0,
            max_tokens=700,
        )
        return self._normalize_plan(self._extract_json(raw))

    def _chat_reply(self, text: str) -> str:
        prompt = (
            f"최근 대화:\n{self._history_block(limit=8)}\n\n"
            f"현재 사용자 입력:\n{text}\n\n"
            "위 맥락을 이어서 자연스럽게 답변해줘."
        )
        return self.llm.chat_text(prompt, system_prompt=CHAT_SYSTEM_PROMPT, temperature=0.4, max_tokens=500).strip()

    def _handle_confirmation(self, text: str) -> str:
        token = text.strip().lower()
        pending = self.pending_action
        self.pending_action = None
        if pending is None:
            return self._chat_reply(text)
        if token in {x.lower() for x in YES_WORDS}:
            return self._execute_plan(pending.plan)
        if token in {x.lower() for x in NO_WORDS}:
            return "알겠어요. 이번 요청은 취소할게요."
        self.pending_action = pending
        return "진행 여부를 '응' 또는 '아니오'로 알려주세요."

    def _handle_pending_fill(self, user_text: str) -> str:
        pending = self.pending_fill
        if pending is None:
            return self._chat_reply(user_text)
        updated_plan = self._fill_pending_plan(pending.plan, user_text)
        self.pending_fill = None

        missing_field = self._find_missing_field(updated_plan)
        if missing_field:
            return self._ask_for_missing(updated_plan, missing_field)

        if updated_plan.get("intent") == "oracle_query":
            result = self.query_service.execute(updated_plan.get("query_name") or "code_finder", updated_plan.get("query_params") or {})
            self.last_query_result = result
            return result.summary

        rendered = self._render_plan(updated_plan)
        if updated_plan.get("needs_confirmation"):
            self.pending_action = PendingAction(plan=updated_plan)
            return rendered + "\n\n진행할까요? (응/아니오)"

        return rendered + "\n\n" + self._execute_plan(updated_plan)

    def _fill_pending_plan(self, plan: dict[str, Any], user_text: str) -> dict[str, Any]:
        prompt = (
            f"기존 plan JSON:\n{json.dumps(plan, ensure_ascii=False)}\n\n"
            f"최근 대화:\n{self._history_block(limit=8)}\n\n"
            f"사용자 추가 입력:\n{user_text}"
        )
        try:
            raw = self.llm.chat_text(prompt, system_prompt=SLOT_FILL_SYSTEM_PROMPT, temperature=0.0, max_tokens=600)
            return self._normalize_plan(self._extract_json(raw))
        except Exception:
            return self._fallback_fill_pending(plan, user_text)

    def _fallback_fill_pending(self, plan: dict[str, Any], user_text: str) -> dict[str, Any]:
        updated = json.loads(json.dumps(plan, ensure_ascii=False))
        missing = self._find_missing_field(updated)
        text = user_text.strip()
        if missing == "item":
            updated.setdefault("query_params", {})["item"] = text
        elif missing == "targets":
            updated["targets"] = [x.strip() for x in re.split(r"[,/]+", text) if x.strip()] or [text]
        elif missing == "message":
            updated["message"] = text
        elif missing == "time":
            delay_minutes, scheduled_at = self._parse_schedule_text(text)
            updated["delay_minutes"] = delay_minutes
            if scheduled_at:
                updated["scheduled_at"] = scheduled_at
        updated["needs_confirmation"] = False
        return updated

    def _find_missing_field(self, plan: dict[str, Any]) -> str | None:
        intent = (plan.get("intent") or "").strip()
        targets = [x for x in (plan.get("targets") or []) if str(x).strip()]
        message = (plan.get("message") or "").strip()
        if intent in {"send_message_now", "schedule_message", "send_table_now", "send_card_now"} and not targets:
            return "targets"
        if intent in {"send_message_now", "schedule_message"} and not message:
            return "message"
        if intent == "schedule_message":
            delay = int(plan.get("delay_minutes", 0) or 0)
            scheduled_at = (plan.get("scheduled_at") or "").strip()
            if delay <= 0 and not scheduled_at:
                return "time"
        if intent == "oracle_query":
            qp = plan.get("query_params") or {}
            if not (qp.get("item") or "").strip():
                return "item"
        return None

    def _ask_for_missing(self, plan: dict[str, Any], field: str) -> str:
        questions = {
            "targets": "누구에게 보낼까요? 예: 연홍석 또는 yeon_hs",
            "message": "보낼 메시지 내용을 알려주세요.",
            "time": "언제 보낼까요? 예: 120분 뒤 / 2시간 뒤 / 2026-03-20 09:00",
            "item": "어떤 파트넘버를 조회할까요? 예: K9YHGB8J1M",
        }
        self.pending_fill = PendingFill(plan=plan, missing_field=field, question=questions[field])
        return questions[field]

    def _handle_local_command(self, text: str) -> str:
        lowered = text.strip().lower()
        if "사람 캐시" in text and ("새로고침" in text or "갱신" in text):
            info = self.people.refresh_cache()
            return f"사람 캐시를 새로고침했어요.\n- 건수: {info.get('count', 0)}\n- 시각: {info.get('updated_at', '')}"
        if "최근 예약" in text or "예약 보여" in text or "예약 목록" in text:
            return self._format_recent_jobs()
        if self.last_query_result is not None and ("표로 보내" in text or "표 보내" in text):
            plan = {
                "intent": "send_table_now",
                "targets": [],
                "table_title": self.last_query_result.title,
                "needs_confirmation": False,
            }
            return self._ask_for_missing(plan, "targets")
        return self._chat_reply(text)

    def _looks_like_local_command(self, text: str) -> bool:
        return any(k in text for k in ["사람 캐시", "예약 목록", "최근 예약"]) or (
            self.last_query_result is not None and any(k in text for k in ["표로 보내", "표 보내"])
        )

    def _render_plan(self, plan: dict[str, Any]) -> str:
        intent = plan.get("intent", "")
        if intent == "send_message_now":
            return f"Knox 즉시 발송으로 이해했어요.\n- 대상: {', '.join(plan.get('targets') or [])}\n- 메시지: {plan.get('message', '')}"
        if intent == "schedule_message":
            when = plan.get("scheduled_at") or f"{int(plan.get('delay_minutes', 0) or 0)}분 뒤"
            return f"Knox 예약 발송으로 이해했어요.\n- 대상: {', '.join(plan.get('targets') or [])}\n- 시각: {when}\n- 메시지: {plan.get('message', '')}"
        if intent == "send_table_now":
            return f"최근 조회 결과를 표로 보낼게요.\n- 대상: {', '.join(plan.get('targets') or [])}"
        if intent == "send_card_now":
            return f"Adaptive Card를 보낼게요.\n- 대상: {', '.join(plan.get('targets') or [])}"
        if intent == "oracle_query":
            qp = plan.get("query_params") or {}
            return f"Oracle 조회로 이해했어요.\n- query: {plan.get('query_name') or 'code_finder'}\n- item: {qp.get('item', '')}"
        if intent == "list_jobs":
            return "최근 예약 목록을 보여드릴게요."
        if intent == "refresh_people_cache":
            return "사람 캐시를 새로고침할게요."
        return "이해한 작업을 진행할게요."

    def _execute_plan(self, plan: dict[str, Any]) -> str:
        if not self.engine_ready and plan.get("intent") in {"send_message_now", "schedule_message", "send_table_now", "send_card_now"}:
            self.bootstrap_engine()

        intent = plan.get("intent")
        if intent == "send_message_now":
            login_ids = self._resolve_targets(plan.get("targets") or [])
            room = self._create_room(login_ids, chat_type=plan.get("chat_type", 0) or 0)
            send_result = self.knox.send_text(chatroom_id=room["chatroomId"], text=plan.get("message", ""), msg_ttl=7200)
            return self._send_result_text(room, send_result)

        if intent == "schedule_message":
            run_at = self._resolve_run_at(plan)
            job_id = self.job_store.add_job(plan, run_at)
            return f"예약 등록 완료\n- job_id: {job_id}\n- 실행시각: {run_at.strftime('%Y-%m-%d %H:%M:%S')}"

        if intent == "send_table_now":
            if self.last_query_result is None:
                raise RuntimeError("최근 조회 결과가 없어요. 먼저 Oracle 조회를 실행해 주세요.")
            login_ids = self._resolve_targets(plan.get("targets") or [])
            room = self._create_room(login_ids, chat_type=plan.get("chat_type", 0) or 0)
            send_result = self.knox.send_table_csv_msg7(
                chatroom_id=room["chatroomId"],
                df=self.last_query_result.df,
                title=plan.get("table_title") or self.last_query_result.title,
            )
            return self._send_result_text(room, send_result)

        if intent == "send_card_now":
            login_ids = self._resolve_targets(plan.get("targets") or [])
            room = self._create_room(login_ids, chat_type=plan.get("chat_type", 0) or 0)
            send_result = self.knox.send_adaptive_card(chatroom_id=room["chatroomId"], card=CARD_TEMPLATE)
            return self._send_result_text(room, send_result)

        if intent == "oracle_query":
            result = self.query_service.execute(plan.get("query_name") or "code_finder", plan.get("query_params") or {})
            self.last_query_result = result
            return result.summary

        if intent == "refresh_people_cache":
            info = self.people.refresh_cache()
            return f"사람 캐시를 새로고침했어요.\n- 건수: {info.get('count', 0)}\n- 시각: {info.get('updated_at', '')}"

        if intent == "list_jobs":
            return self._format_recent_jobs()

        return self._chat_reply(plan.get("message") or "")

    def _resolve_targets(self, targets: list[str]) -> list[str]:
        result = self.people.resolve_targets(targets)
        if result.ambiguous:
            parts = []
            for name, rows in result.ambiguous.items():
                lines = [f"- {name} 후보 {len(rows)}명"]
                for idx, row in enumerate(rows[:10], 1):
                    lines.append(f"  {idx}) {row.get('kor_name', '')} / {row.get('dept_name', '')} / {row.get('sso_id', '')}")
                parts.append("\n".join(lines))
            raise RuntimeError("동명이인이 있어요. 더 구체적으로 말씀해 주세요.\n" + "\n\n".join(parts))
        if result.missing_inputs:
            raise RuntimeError("대상을 찾지 못했어요: " + ", ".join(result.missing_inputs))
        if not result.resolved_loginids:
            raise RuntimeError("보낼 대상을 찾지 못했어요.")
        return result.resolved_loginids

    def _create_room(self, login_ids: list[str], chat_type: int = 0) -> dict[str, Any]:
        mapping = self.knox.resolve_user_ids_from_loginids(login_ids)
        missing = [x for x in login_ids if x not in mapping]
        if missing:
            raise RuntimeError("Knox userID 조회 실패: " + ", ".join(missing))
        user_ids = [mapping[x] for x in login_ids]
        return self.knox.create_chatroom(receivers=user_ids, chat_type=chat_type)

    def _send_result_text(self, room: dict[str, Any], send_result: dict[str, Any]) -> str:
        entries = send_result.get("processedMessageEntries", []) or []
        sent = entries[0].get("sentTime") if entries else ""
        return f"전송 완료\n- chatroomId: {room.get('chatroomId')}\n- sentTime: {sent}"

    def _resolve_run_at(self, plan: dict[str, Any]) -> datetime:
        delay = int(plan.get("delay_minutes", 0) or 0)
        if delay > 0:
            return datetime.now() + timedelta(minutes=delay)
        scheduled_at = (plan.get("scheduled_at") or "").strip()
        if not scheduled_at:
            raise RuntimeError("예약 시각 정보가 없습니다.")
        for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S"):
            try:
                return datetime.strptime(scheduled_at, fmt)
            except ValueError:
                continue
        raise RuntimeError(f"예약 시각 형식을 이해하지 못했어요: {scheduled_at}")

    def _format_recent_jobs(self) -> str:
        rows = self.job_store.list_recent(limit=20)
        if not rows:
            return "최근 예약이 없습니다."
        lines = ["최근 예약 목록"]
        for row in rows:
            payload = row.get("payload") or {}
            lines.append(
                f"- {row['run_at']} / {row['status']} / {payload.get('intent', '')} / "
                f"{', '.join(payload.get('targets') or [])} / {payload.get('message', '')}"
            )
        return "\n".join(lines)

    def _extract_json(self, raw: str) -> dict[str, Any]:
        raw = raw.strip()
        try:
            return json.loads(raw)
        except Exception:
            pass
        m = re.search(r"\{.*\}", raw, re.S)
        if not m:
            raise ValueError(f"JSON 파싱 실패: {raw}")
        return json.loads(m.group(0))

    def _normalize_plan(self, plan: dict[str, Any]) -> dict[str, Any]:
        out = dict(plan or {})
        out.setdefault("intent", "chat")
        out.setdefault("targets", [])
        out.setdefault("message", "")
        out.setdefault("chat_type", 0)
        out.setdefault("delay_minutes", 0)
        out.setdefault("scheduled_at", "")
        out.setdefault("table_title", "조회 결과")
        out.setdefault("query_name", "code_finder")
        out.setdefault("query_params", {})
        out.setdefault("needs_confirmation", False)
        out.setdefault("confidence", 0.0)
        out.setdefault("reason", "")
        if isinstance(out["targets"], str):
            out["targets"] = [out["targets"]]
        out["targets"] = [str(x).strip() for x in out.get("targets") or [] if str(x).strip()]
        try:
            out["delay_minutes"] = int(out.get("delay_minutes", 0) or 0)
        except Exception:
            out["delay_minutes"] = 0
        if not isinstance(out.get("query_params"), dict):
            out["query_params"] = {}
        if out["intent"] == "chat":
            delay_minutes, scheduled_at = self._parse_schedule_text(out.get("message", ""))
            if delay_minutes > 0 and not out["delay_minutes"]:
                out["delay_minutes"] = delay_minutes
            if scheduled_at and not out.get("scheduled_at"):
                out["scheduled_at"] = scheduled_at
        return out

    def _parse_schedule_text(self, text: str) -> tuple[int, str]:
        txt = (text or "").strip()
        m = re.search(r"(\d+)\s*분\s*뒤", txt)
        if m:
            return int(m.group(1)), ""
        m = re.search(r"(\d+)\s*시간\s*뒤", txt)
        if m:
            return int(m.group(1)) * 60, ""
        m = re.search(r"(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}(?::\d{2})?)", txt)
        if m:
            return 0, m.group(1)
        return 0, ""

    def _history_block(self, limit: int = 8) -> str:
        lines = []
        for item in self.history[-limit:]:
            lines.append(f"{item['role']}: {item['content']}")
        return "\n".join(lines) if lines else "(없음)"

    def _add_history(self, role: str, content: str):
        self.history.append({"role": role, "content": content})
        if len(self.history) > 30:
            self.history = self.history[-30:]
