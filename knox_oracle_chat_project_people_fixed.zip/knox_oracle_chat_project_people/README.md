# Knox + Oracle Chat (People Cache Included)

## 개요
- 채팅형 tkinter 앱
- Knox 즉시 발송 / 예약 발송 / 표(msg7) / Adaptive Card
- Oracle 파트넘버 조회
- 사람 이름 -> SSO_ID -> Knox userID 매핑 캐시

## 실행
```bash
pip install -r requirements.txt
python app.py
```

## 필수
같은 폴더에 `knox_messenger_engine.py` 를 두세요.

## 먼저 바꿀 값
- `config.py` 의 `KNOX_SYSTEM_ID`
- `config.py` 의 `KNOX_TOKEN`

## 예시
- 연홍석에게 지금 테스트 메시지 보내줘
- 조성묵에게 2시간 뒤에 회의 시작이라고 보내줘
- K9YHGB8J1M 조회해줘
- 사람 캐시 새로고침

## 사람 캐시
- Oracle `SCM_WP.T_T_FOR_MASTER` 에서 공급망 조직 사람 목록을 가져와 JSON 캐시에 저장
- 앱 시작 시 캐시가 없거나 오래됐으면 자동 새로고침
- 한글 이름 입력 시 캐시를 먼저 사용
